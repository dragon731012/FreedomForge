<p align="center"><img src="/img/logo.png" height="200">
</p>

<h1 align="center">DM unbl0cker static</h1>

<h4 align="center">uses ultraviolet to search the web freely. (no games in static version)</h3>

<p align="center">
<a href="https://discord.gg/hrXXUeWgrn">
  <img src="https://dcbadge.vercel.app/api/server/hrXXUeWgrn"/>
</a>
</p>
<h1></h1>
<h2>deployment</h2>

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https%3A%2F%2Fgithub.com%2Fdragon731012%2FDM-unbl0cker%2Ftree%2Fstatic)
[![Deploy with Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/dragon731012/DM-unbl0cker)

[View non-static proxy with games here.](https://github.com/dragon731012/DM-Unbl0cker/tree/non-static)
